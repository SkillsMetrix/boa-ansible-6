from fastapi import FastAPI

from . import crudapp

app= FastAPI()

app.include_router(crudapp.router)
