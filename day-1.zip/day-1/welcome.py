print('welcome to python')

print('welcome again')

