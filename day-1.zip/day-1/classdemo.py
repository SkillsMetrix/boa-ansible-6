

class User:
    name='shashi'
    state='MH'

# constructor
    def __init__(self,email='none@mail.com',city='pune'):
        self.email=email
        self.city=city

    def showState(self):
        print(self.state)

    def __str__(self):
        return f"{self.name} ** {self.email} ** {self.city}"

# obj-1
user= User()

# obj-2
user2= User('usr@mail.com','pune')
print(user)
print(user2)
user.showState()