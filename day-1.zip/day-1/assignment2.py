# declare empty array
use_numbers=[]

# ask the user to add the value

data= int(input('How many number you wana add...!'))

# take the value

for i in range(data):
    num= int(input (f"Enter numbers {i+1}"))
    use_numbers.append(num)
print(use_numbers)

for num in use_numbers:
    if(num%2==0):
        print(f"{num} is even")
    else:
         print(f"{num} is odd")