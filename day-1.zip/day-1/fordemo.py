
userNames=['admin','manager','QA']

for uname in userNames:
    print(uname)


projectTypes=['hrms','IT','finance','Banking']

dummy=[]

for project in projectTypes:
    if project =='Banking':
        continue
    else:
        print(f"Developing project {project}")
dummy.append('Banking')
print(f"Developed {dummy}")
