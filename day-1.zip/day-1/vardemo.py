
# not allowed int a=10

a='hello'

a=10
b=5
if a > b:
    print('statement is true')
else:
    print('statement is false')

b='welcome'

print(a,b)

myname='Amarjeet'

city='pune'

pin= 12345

print(f"My Name is {myname} ,my city is {city} with pincode {pin}")


