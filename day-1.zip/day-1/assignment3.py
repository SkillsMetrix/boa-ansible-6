
# style-1

def sumOfArray(arr):
    total=0
    for num in arr:
        total +=num
    return total

numbers=[12,21,13,31]
result=sumOfArray(numbers)
print(f"this addition is {result}")

# style-2

def sumOfArray(*arr):
    total=0
    for num in arr:
        total +=num
    return total

result=sumOfArray(12,21,13,31)
print(f"this addition is {result}")