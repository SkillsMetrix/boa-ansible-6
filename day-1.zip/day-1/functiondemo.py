

def showWelcome():
    print('welcome message')

showWelcome()

def calculator(x,y):
    return x+y

print(calculator(12,13))