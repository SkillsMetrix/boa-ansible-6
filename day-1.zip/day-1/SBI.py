
from RBI import RBI

class SBI(RBI):
     def depositAmount(self):
         print('amount deposited in SBI')
     def withdrawAmount(self):
        print('amount withdrawn in SBI')

sbiBank= SBI()
sbiBank.depositAmount()
sbiBank.withdrawAmount()