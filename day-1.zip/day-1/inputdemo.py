


a = int(input('enter value for a'))
b =int(input('enter value for a'))

print (f"additionis  {a+b}")





